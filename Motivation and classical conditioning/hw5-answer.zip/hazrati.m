clear all; close all; clc;

trial = 100;
v = normrnd(0,0.1,1,trial);
v_r = normrnd(0,0.5,1,trial);
phi = normrnd(0,3,1,trial);
WN = 0.02;
phi(40) = -2;
phi(90) = 4;
c = zeros(1,trial);
c(40) = 1;
c(90) = 1;
w = zeros(1,trial);
r = zeros(1,trial);
w(1) = 0;
r(1) = w(1) + v_r(1) + c(1)*phi(1);
for i = 1:trial
    if (trial == 40)||(trial == 90)
    c = 1;
    end
    w(i+1) = w(i) + v(i) + c(i) * phi(i);
    r(i) = w(i) + v_r(i) + c(i)*phi(i);
end
plot(0:trial,w,'o')
title('learning scheme')
ylabel('W')
xlabel('trial')
hold on
plot(0:trial-1,r,'x')
ylim([-4 4]);
xlabel('t')
ylabel('w')
legend('w','r')
clear sigma

trial=100;
w1=zeros(1,20);
sigma = zeros(1,trial);
w1(1) =0;
u = [ones(1,trial)];
tau = 0.7;
w_n = (0.01); 
sigma0 =0.6 ;
sigma(1)=sigma0;
gamma = 3;
w0 = 0;
tau = 0.7;
sigma0 = 0.6;
p=[];
% 
for i=2:trial-1
    sigma(i+1) = sigma(i)+ w_n;
    G = sigma(i+1) * u(i) * (u(i)' * sigma(i+1) * u(i) + tau^2)^(-1);
    sigma(i+1) = sigma(i+1) - G*c(i)'* sigma(i+1);
    w1(i+1) = w1(i) + G * (r(i) - u(i)'* w1(i));
    beta(i) = (r(i) - u(i)*w1(i))^2 / (u(i)*sigma(i) + tau^2);
    if beta > gamma
     sigma(i) = 60;
    end
end
figure
scatter(0:trial,w,20)
hold on
title('learning scheme')
scatter(0:trial-1,r,'xk')
hold on
scatter(0:trial-1,w1);
ylim([-4 4])
legend('w','r','w1');
ylabel('W')
xlabel('trials')
figure
title('learning scheme')
ylabel('W')
xlabel('trials')
hold on
plot(beta)
title('Corresponding levels')
ylabel('Beta')
xlabel('trials')
hold on
y=3;
x=[0:0.1:110];
y=[0:10:2060];
g=3;
% yline(3.3)
ylim([0 10])
xlim([0 100])
legend('NE','gamma')

n = 200;
gV = linspace(0,30,n);
MSE = zeros(1,n);
for j = 1:1000
    nTrials = 100;
        s = rng;
        v = normrnd(0,0.1,1,nTrials);
        vr = normrnd(0,0.5,1,nTrials);
        phi = normrnd(0,2,1,nTrials);
        c = zeros(1,nTrials);
        c(40) = 1;
        c(90) = 1;
        phi(40) = -2;
        phi(90) = 4;
        ind = find(c==1);
        w = zeros(1,nTrials);
        r = w;
        w(1) = 1;
        r(1) = w(1) + vr(1) + c(1)*phi(1);
        for i = 2:nTrials
            w(i) = w(i-1) + v(i-1) + c(i-1) * phi(i-1);
            r(i) = w(i) + vr(i) + c(i)*phi(i);
        end
        mseTmp = [];
        for i1 = 1:n
        gamma = gV(i1);   
        w2 = zeros(1,nTrials);
        sigma = zeros(1,nTrials);
        betaVec = zeros(1,nTrials);
        w2(1) = w0;
        sigma(1) = sigma0;
        for i = 2:nTrials
            sigmap = sigma(i-1) + WN;
            G = sigmap*u(i)*(u(i)*sigmap+tau^2)^-1;
            sigma(i)=sigmap - G*u(i)*sigmap;
            w2(i)= w2(i-1)+G*(r(i)-u(i)*w2(i-1));
            beta = (r(i) - u(i)*w(i))^2 / (u(i)*sigma(i) + tau^2);
            betaVec(i) = beta; 
            if beta > gamma
                sigma(i) = 100;
            end
        end
            tmp =sum((w2-w).^2);
            mseTmp=[mseTmp,tmp];
    end
    MSE=MSE+mseTmp;
end
MSE = MSE/1000;
figure
plot(gV,MSE)
yline(MSE(1));
yline(min(MSE));
ylim([0 50])
xlabel("$\gamma$",'interpreter','latex')
ylabel("MSE")
gV(min(MSE))
