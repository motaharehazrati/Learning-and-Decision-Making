clear
clc
close all;
map=zeros(15,15);
map(10,10)=10; %reward
map(6,8)=-10; %punishment
starting_point=randi(15,1,2);
while isequal(starting_point,map(10,10)) || isequal(starting_point,map(6,8))
      starting_point=randi(15,1,2);
end
mapp=zeros(15,15,4);
for i=1:15
    for j=1:15
        mapp(i,j,:)=[0.25 0.25 0.25 0.25];
    end
end
for ii = 2: 14
        mapp(1, ii, :) = [0.33 0.33 0 0.34];
        mapp(ii, 1, :) = [0.33 0 0.33 0.34];
        mapp(15, ii, :)= [0.33 0.34 0.33 0];
        mapp(ii, 15, :)= [0 0.33 0.33 0.34];
end
mapp(1, 1, :) = [0.5 0 0 0.5];
mapp(1, 15, :) = [0.5 0 0 0.5];
mapp(15, 1, :) = [0.5 0 0 0.5];
mapp(15, 15, :) = [0.5 0 0 0.5];