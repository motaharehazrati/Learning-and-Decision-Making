clear
clc
mapp=zeros(15,15,4);
map=zeros(15,15);
map(10,10)=10; %reward
map(6,8)=-10; %punishment
reward=[10 10];
punishment=[6 8];
gamma=0.8;
ep=0.5;
% 1=up 2=right 3=left 4=down
for i = 2: 14
     mapp(1, i, 1) = nan;
     mapp(i, 15, 2) = nan;
     mapp(i, 1, 3) = nan;
     mapp(15, i, 4) = nan;     
end
mapp(1, 1, [1 3]) = nan;
mapp(1, 15, [1 2]) = nan;
mapp(15, 1, [4 3]) = nan;
mapp(15, 15, [2 4]) = nan;
moving_position=[];
for trial=1:100
    starting_point=randi(15,1,2);
    t=1;
    while isequal(starting_point,map(10,10)) || isequal(starting_point,map(6,8))
      starting_point=randi(15,1,2);
    end
    moving_position(1, :) = starting_point(trial, :);
    V = max(mapp, [], 3);
    while (moving_position(t, 1) ~= reward(1) || moving_position(t, 2) ~= reward(2)) &&...
                (moving_position(t, 1) ~= punishment(1) || moving_position(t, 2) ~= punishment(2))
        move=find(~isnan(mapp(starting_point(1),starting_point(2),:)));    
        maxA = max(mapp(starting_point(1),starting_point(2),move));
        action = find(mapp(starting_point(1),starting_point(2),:) == maxA);
        if (length(action)>1)
             rndInd = randi(length(action));
             action = action(rndInd);
        end
        posVec = [starting_point(1);starting_point(2)];
        side = [[0 1];[1 0];[-1 0];[0 -1]];
        new_move = [starting_point(1),starting_point(2)] + side(action,:);
        delta(t) = map(new_move(1), new_move(2)) + gamma * V(new_move(1),new_move(2)) - mapp(moving_position(t, 1), moving_position(t, 2), action); 
        mapp(moving_position(t, 1), moving_position(t, 2), action) = mapp(moving_position(t, 1),...
                moving_position(t, 2), action) + ep * delta(t);

        t = t + 1;

        moving_position(t, :) = new_move;
        V = max(mapp, [], 3);  
    end
    StepTrial(trial) = t;
    optimal(trial) = abs(starting_point(trial, 1) - reward(1)) + abs(starting_point(trial, 2) - reward(2)) + 1;
    Pos{trial} = moving_position;
        
    Vend{itrl} = V;
end
    figure;
trial_vec = floor(linspace(1, Num_trials, 10));
for i = 1: length(trial_vec)
    trial = trial_vec(i);
    movepos = Pos{trial};
    
    x = movepos(:, 2);
    y = 15+1 - movepos(:, 1);
    
    subplot(5, 5, i)
    plot(x, y)
    hold all;
    plot(reward(2), 15-reward(1)-1, 'o', 'color', 'black', 'linewidth', 2)
    plot(punishment(2), 15-punishment(1)-1, 'o', 'color', 'red', 'linewidth', 2)
    plot(x, y, 'color', 'black')
    xlim([1 15])
    ylim([1 15])
    plot(initPos(trial, 2), 16-initPos(trial, 1), 'o', 'color', 'yellow', 'linewidth', 2)
    title(['Trial ', num2str(trial)]);
    grid on;
    grid minor
end

figure;
contour(log10(V))
colorbar;
title('contour plot of the learned values ');
figure
[px py] = gradient(flip(V));
quiver(px, py)
title('gradient plot of the learned values ');  
    
    
    