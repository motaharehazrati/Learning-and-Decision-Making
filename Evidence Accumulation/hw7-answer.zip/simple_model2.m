function [choice] = simple_model2(bias,sigma,startpoint,T)

    prob=cdf('normal',startpoint,startpoint+bias*T,sqrt(sigma*T));
    inp=rand(1);
    if inp>prob
        choice=1;
    else
        choice=-1;  
    end
end

