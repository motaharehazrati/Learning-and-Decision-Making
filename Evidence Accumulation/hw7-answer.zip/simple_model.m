function [choice,x] = simple_model(bias, sigma,dt ,T)
    x =zeros(1,round(T/dt));
    for i = 2: round(T/dt)
        x(i) = x(i-1) + bias*dt + sigma * normrnd(0,sqrt(dt));
    end
    choice = sign(x(end));
end

