clear
clc
close all;
% % question2 part1
% dt = 0.1;
% T = 1;
% bias = 1;
% sigma = 1;
% xvec=[];
% for i = 1:20
%     [choice,x] = simple_model(bias,sigma,dt,T);
%     choicevec(i) = choice;
%     xvec=[xvec x];
% end
% figure;
% hist(xvec,50)
% histfit(xvec);
% title("histogram of X(t)")

% % question2 part2
clear 
clc
% bias= [-1 0 0.1 1 10];
% bias=[6 8 10 12];
% x_b=[];
% dt = 0.1;
% sigma = 1;
% T=10;
% figure
% for i=1:length(bias)
%     [choice,x(i,:)]=simple_model(bias(i) , sigma , dt,T);
% %     x_b=[x_b x];
%     plot(0:dt:T-dt, x(i,:),'linewidth',2);
%     hold on
% end
% xlabel("Time(s)")
% ylabel("x(t)")
% legend("B = -1","B = 0","B = 0.1","B = 1","B = 10",'location','northwest')
% legend("B = 6","B = 8","B = 10","B = 12",'location','northwest')
% %question 3
% % clear
% % clc
% % dt = 0.1;
% % bias = 0.1;
% % sigma = 1;
% % Tvec = linspace(0.5,10,100);
% % trial=1000;
% % choice_T=[];
% % error=[];
% % for T= Tvec
% %     for i=1:trial
% %         [choice,x]=simple_model(bias,sigma,dt,T);
% %         choice_T=[choice_T ,choice];
% %     end
% %     p=length(find(choice_T == 1));
% %     error=[error 1-p/trial];
% %     
% % end
% % figure
% % plot(Tvec,error,'m','linewidth',2)
% % xlabel("T")
% % ylabel("error")   
% %question4
% clear
% clc
% dt = 0.1;
% bias = 0.1;
% sigma = 1;
% T=10;
% trial=10;
% xvec=[];
% for i = 1:trial
%     [~,x] = simple_model(bias,sigma,dt,T);
%     xvec = [xvec;x];
%     t = linspace(0,T,round(T/dt));
% end
%     
% stdX = stdc(xvec,[],1);
% meanX = mean(xvec,1);
% meanc = bias*t;
% stdc = sqrt(sigma*t);    
% figure;
% % plot(t,xvec(1,:),'color',[0.5,0.7,0.5]);
% hold on
% plot(t,meanX,'m','linewidth',1.5)
% hold on
% plot(t,stdX,'m','linewidth',1.5)
% xlabel("time")
% hold on
% plot(t,meanX+stdX,'--m','linewidth',1.5)
% hold on
% plot(t,meanX-stdX,'--m','linewidth',1.5)
% hold on
% plot(t,meanc,'c','linewidth',1.5)
% hold on
% plot(t,meanc+stdc,'--c','linewidth',1.5)
% hold on
% plot(t,meanc-stdc,'--c','linewidth',1.5)  
% hold on
% plot(t,xvec(:,:),'color','k');
% xlabel('time'); 
% ylabel('x(t)'); 
% legend('mean & std','calculated mean and std');
%question5
% clear
% clc
% startpoint=linspace(-4,5,10);
% for i=1:length(startpoint)
%     for j=1:5000
%         choice(i,j)=simple_model2(0.1,1,startpoint(i),10);
%     end
%     choicevec(i) = length(find(choice(i, :) == 1))/length(choice(i, :)*100);
% %     subplot(2,5,i)
% %     hold on
% %     plot(choicevec,'k','linewidth',1.5)
% end
% plot(startpoint,choicevec,'*','color','b','linewidth',1.5)    
% xlabel("diffrent startpoint")
% ylabel("choosing option")    
%     
% %question7
% clear
% clc
% x0 = 0;
% dt = 0.1;
% posth = 1;
% negth = -1;
% bias = 0.1;
% sigma = 1;
% RTvec = [];
% choicevec = [];
% for i = 1:1000
%     [RT,choice] = two_choice_trial(posth,negth,sigma,x0,bias,dt);
%     RTvec(i) = RT;
%     choicevec(i) = choice;
% end
% correct = find(choicevec == 1);
% wrong = find(choicevec == -1);
% figure
% hist(RTvec,100);
% title("RT distribution")
% figure
% hist(RTvec(correct),100);
% title("RT distribution for correct decision")
% figure
% hist(RTvec(wrong),100);
% title("RT distribution for wrong decision")
% % figure
% % plot(RTvec(correct),choicevec(correct),'.')

%question8
clear
clc
posth=1;
negth=-1;
sigma1=1;
sigma2=1;
bias1=0.1;
bias2=0.1;
x01 = 0.1;
x02 = -0.1;
dt = 0.1;
T=10;
figure
for i=1:1:3
    
    [RT(i),choice,x1{i},x2{i}] = race_trial(posth,negth,sigma1,sigma2,bias1,bias2,x01,x02,dt,T);
    plot([0: dt: RT(i)], x1{i}, 'linewidth', 1.5);
    hold all;
    plot([0: dt: RT(i)], x2{i},'--', 'linewidth', 1.5);
end
% plot(0:RT,x1,'.')
% hold on
% plot(0:RT,x2,'.')
% 
