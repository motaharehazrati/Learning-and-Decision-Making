function [RT,choice,x1,x2] = race_trial(posth,negth,sigma1,sigma2,bias1,bias2,x01,x02,dt,T)
      t = 0;
      x1 = x01;
      x2 = x02;
    while (x1 < posth && x1>negth && x2 < negth && x2>negth )
        x1 = x1 + bias1 * dt + sigma1 * normrnd(0,sqrt(dt));
        x2 = x2 + bias2 * dt + sigma2 * normrnd(0,sqrt(dt));
        t = t+dt;
    end
    RT = t;
    if (x1 >= posth || x2 >= posth)
        choice = 1;
    else
        choice = -1;
    end
    
end  


