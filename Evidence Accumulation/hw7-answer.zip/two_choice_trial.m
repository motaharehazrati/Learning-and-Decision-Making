function [RT,choice] = two_choice_trial(posth,negth,sigma,x0,bias,dt)
    x = x0;
    t = 0;
    while (x <= posth && x >= negth)
        x = x + bias * dt + sigma * normrnd(0,sqrt(dt));
        t = t+dt;
    end
    RT = t;
    if (x >= posth)
        choice = 1;
    else
        choice = -1;
    end

end

